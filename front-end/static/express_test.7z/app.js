/*
 * @Author: Crayon
 * @Date: 2021-04-13 21:48:57
 * @Last Modified by: Crayon
 * @LastEditTime: 2021-04-13 22:02:22
*/
const express = require('express')
const app = express()
const { port } = require('./config/common.conf')


app.get('/testGet', (req, res) => {
    res.send('Hello World!')
})

app.post('/testPost', (req, res) => {
    res.send('Hello World!')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})
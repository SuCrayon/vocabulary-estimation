/*
 * @Author: Crayon
 * @Date: 2021-04-13 21:51:26
 * @Last Modified by: Crayon
 * @LastEditTime: 2021-04-13 21:55:12
 */
const port = 8080

module.exports = {
    port
}